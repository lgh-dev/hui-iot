import * as G2Plot from '@antv/g2plot'
const container = document.getElementById('app');
const data = [
  {
    "series": "电流",
    "x": "21:30:00",
    "y": 299
  },
  {
    "series": "电流",
    "x": "21:30:01",
    "y": 910
  },
  {
    "series": "电流",
    "x": "21:30:02",
    "y": 776
  },
  {
    "series": "电流",
    "x": "21:30:03",
    "y": 172
  },
  {
    "series": "电流",
    "x": "21:30:04",
    "y": 179
  },
  {
    "series": "电流",
    "x": "21:30:05",
    "y": 634
  },
  {
    "series": "电流",
    "x": "21:30:06",
    "y": 600
  },
  {
    "series": "电流",
    "x": "21:30:07",
    "y": 285
  },
  {
    "series": "电流",
    "x": "21:30:08",
    "y": 989
  },
  {
    "series": "电流",
    "x": "21:30:09",
    "y": 575
  },
  {
    "series": "电压",
    "x": "21:30:00",
    "y": 871
  },
  {
    "series": "电压",
    "x": "21:30:01",
    "y": 248
  },
  {
    "x": "21:30:02",
    "y": 646,
    "series": "电压"
  },
  {
    "x": "21:30:03",
    "y": 910,
    "series": "电压"
  },
  {
    "series": "电压",
    "x": "21:30:04",
    "y": 776
  },
  {
    "series": "电压",
    "x": "21:30:05",
    "y": 172
  },
  {
    "series": "电压",
    "x": "21:30:06",
    "y": 179
  },
  {
    "series": "电压",
    "x": "21:30:07",
    "y": 634
  },
  {
    "series": "电压",
    "x": "21:30:08",
    "y": 600
  },
  {
    "series": "电压",
    "x": "21:30:09",
    "y": 285
  },
  {
    "series": "功率",
    "x": "21:30:00",
    "y": 871
  },
  {
    "series": "功率",
    "x": "21:30:01",
    "y": 248
  },
  {
    "series": "功率",
    "x": "21:30:02",
    "y": 646
  },
  {
    "series": "功率",
    "x": "21:30:03",
    "y": 910
  },
  {
    "series": "功率",
    "x": "21:30:04",
    "y": 776
  },
  {
    "series": "功率",
    "x": "21:30:05",
    "y": 172
  },
  {
    "series": "功率",
    "x": "21:30:06",
    "y": 179
  },
  {
    "series": "功率",
    "x": "21:30:07",
    "y": 634
  },
  {
    "series": "功率",
    "x": "21:30:08",
    "y": 600
  },
  {
    "series": "功率",
    "x": "21:30:09",
    "y": 285
  }
];
const config = {
  "title": {
    "text": "堆叠面积图"
  },
  "description": {
    "text": "一个简单的堆叠面积图"
  },
  "legend": {
    "position": "top-center",
    "flipPage": false
  },
  "smooth": true,
  "line": {
    "size": 1
  },
  "forceFit": false,
  "width": 1211,
  "height": 200,
  "xField": "x",
  "yField": "y",
  "stackField": "series",
  "color": [
    "#5B8FF9",
    "#5AD8A6",
    "#5D7092"
  ]
}
const plot = new G2Plot.StackArea(container, {
  data,
  ...config,
});
plot.render();
