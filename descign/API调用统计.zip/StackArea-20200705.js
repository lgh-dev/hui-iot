import * as G2Plot from '@antv/g2plot'
const container = document.getElementById('app');
const data = [
  {
    "series": "应用A",
    "x": "2020-01-01",
    "y": 646
  },
  {
    "series": "应用A",
    "x": "2020-01-02",
    "y": 234
  },
  {
    "series": "应用A",
    "x": "2020-01-03",
    "y": 4234
  },
  {
    "series": "应用A",
    "x": "2020-01-04",
    "y": 343
  },
  {
    "series": "应用A",
    "x": "2020-01-05",
    "y": 2342
  },
  {
    "series": "应用A",
    "x": "2020-01-06",
    "y": 434
  },
  {
    "series": "应用B",
    "x": "2020-01-01",
    "y": 1209
  },
  {
    "series": "应用B",
    "x": "2020-01-02",
    "y": 545
  },
  {
    "series": "应用B",
    "x": "2020-01-03",
    "y": 3434
  },
  {
    "series": "应用B",
    "x": "2020-01-04",
    "y": 343
  },
  {
    "series": "应用B",
    "x": "2020-01-05",
    "y": 545
  },
  {
    "series": "应用B",
    "x": "2020-01-06",
    "y": 455
  },
  {
    "x": "2020-01-07",
    "y": 5456,
    "series": "应用A"
  },
  {
    "x": "2020-01-07",
    "y": 5412,
    "series": "应用B"
  }
];
const config = {
  "title": {
    "visible": true,
    "text": "API调用统计"
  },
  "description": {
    "visible": true,
    "text": "过去7天分应用统计调用次数"
  },
  "legend": {
    "position": "right-top",
    "flipPage": false
  },
  "smooth": true,
  "point": {
    "visible": true
  },
  "forceFit": false,
  "width": 826,
  "height": 300,
  "xField": "x",
  "yField": "y",
  "stackField": "series",
  "color": [
    "#5B8FF9",
    "#5AD8A6"
  ]
}
const plot = new G2Plot.StackArea(container, {
  data,
  ...config,
});
plot.render();
